## 1.0.0-beta.1 (June, 25, 2020)

ENHANCEMENTS:

* `resource/cloudknox_policy` : support AWS policy response larger than 6142 characters by splitting policy into multiple aws policy resources in same file. [GH-#]

## 1.0.0-beta.0 (June 6, 2020)

FEATURES:

* **New Resource:** `cloudknox_policy` [GH-####] 
